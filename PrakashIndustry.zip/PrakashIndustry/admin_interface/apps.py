from django.apps import AppConfig


class AdminInterfaceConfig(AppConfig):
    name = 'admin_interface'
